discovery-agent 1.2.0

See QUICKSTART.md for installation and configuration.
