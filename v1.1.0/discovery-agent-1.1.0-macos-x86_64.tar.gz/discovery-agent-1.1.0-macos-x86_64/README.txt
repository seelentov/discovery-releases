discovery-agent 1.1.0

See QUICKSTART.md for installation and configuration.
